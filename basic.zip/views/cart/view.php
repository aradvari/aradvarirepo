<?php

use yii\helpers\Url;

?>

<h4>Kosarad tartalma</h4>
<div class="cart-container"></div>
<a href="<?= Url::to(['order/create']) ?>" class="btn btn-success btn-lg">Tovább a pénztárhoz</a>
<h2>Sikertelen fizetés!</h2>

<ul>
    <li>Válaszkód (RC): <b><?= $model->rc ?></b></li>
    <li>Válaszüzenet (RT): <b><?= $model->rt ?></b></li>
    <li>Tranzakció azonosító (TRID): <b><?= $model->trid ?></b></li>
</ul>
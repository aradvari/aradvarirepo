<p>Üdvözlünk a Coreshop felhasználói között!</p>

<p>A rendszer sikeresen regisztrált on-line áruházunkban, ahova az alábbi adatokkal tudsz bejelentkezni a jövőben:</p>

<p>
    E-mail cím: <?= $model->email ?>
    <br>
    Jelszó: <?= $password ?>
</p>
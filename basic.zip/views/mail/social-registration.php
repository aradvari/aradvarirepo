<p>Üdvözlünk a Coreshop felhasználói között!</p>

<p>A rendszer a <?= ucfirst($model->auth_type) ?> segítségével sikeresen regisztrált on-line áruházunkban,<br>
    a jövőben is így tudsz bejelentkezni rendszerünkbe.</p>

<p>Regisztrált e-mail címed: <?= $model->email ?></p>
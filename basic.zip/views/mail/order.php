<p>Köszönjük a megrendelésedet, melyet a lenti adatokkal igazolunk vissza!</p>

<?= $this->render('/order/_order_data', ['model' => $model]) ?>